import tensorflow as tf
from model import build_model

def evaluate_model(test_data, model_path):
    test_images, test_labels = test_data['data'], test_data['labels']

    model = tf.keras.models.load_model(model_path)
    loss, accuracy = model.evaluate(test_images, test_labels)
    print(f"Test Loss: {loss}, Test Accuracy: {accuracy}")
